Android Studio project for «دفتر من».
Open this android/ folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
The generated APK should be at app/build/outputs/apk/debug/app-debug.apk.
This source project is prepared but not compiled in this environment because Android SDK/Gradle are unavailable here.
